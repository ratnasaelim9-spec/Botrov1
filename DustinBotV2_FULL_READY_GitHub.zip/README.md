# DustinBotV2_FULL_READY_GitHub

Android bot foundation based on the V1.6 Accessibility/Overlay build.

Included:
- Accessibility Service for screen control and screenshots (Android 11+ screenshot API).
- Overlay BOT / STOP controls.
- Screenshot-based Monster and Item color heuristic detector.
- Automatic tap on detected Monster/Item.
- Configurable attack-button position.
- Multiple configurable walking points, persisted on device.
- Scan and walk timing persisted in the settings layer.
- Service lifecycle is separated from the Activity.
- GitHub Actions workflow for debug APK build.
- No anti-cheat bypass, no client modification, no exploit logic.

Important: generic Monster/Item detection cannot be made game-accurate without the game's actual visual reference/template. V2 therefore uses a configurable color-based heuristic. The first real game setup should calibrate Monster/Item colors and screen regions before unattended use.
