package com.dustinbot.v2;

import android.graphics.Bitmap;
import android.graphics.Color;

public final class VisionEngine {
    public static class Hit { public final int x,y,count; Hit(int x,int y,int c){this.x=x;this.y=y;this.count=c;} }
    private static boolean near(int r,int g,int b,int tr,int tg,int tb,int tol){return Math.abs(r-tr)<=tol&&Math.abs(g-tg)<=tol&&Math.abs(b-tb)<=tol;}
    private static Hit find(Bitmap b,int tr,int tg,int tb){
        if(b==null)return null; int step=Math.max(4,Math.min(b.getWidth(),b.getHeight())/180), n=0,sx=0,sy=0;
        for(int y=step;y<b.getHeight()-step;y+=step) for(int x=step;x<b.getWidth()-step;x+=step){int c=b.getPixel(x,y); if(near(Color.red(c),Color.green(c),Color.blue(c),tr,tg,tb,55)){n++;sx+=x;sy+=y;}}
        if(n<8)return null; return new Hit(sx/n,sy/n,n);
    }
    public static Hit findMonster(Bitmap b, SettingsStore s){return find(b,s.monsterR(),s.monsterG(),s.monsterB());}
    public static Hit findItem(Bitmap b, SettingsStore s){return find(b,s.itemR(),s.itemG(),s.itemB());}
}
