package com.dustinbot.v2;

import android.app.Activity;import android.content.ComponentName;import android.content.Intent;import android.graphics.Color;import android.net.Uri;import android.os.Bundle;import android.provider.Settings;import android.view.Gravity;import android.widget.Button;import android.widget.EditText;import android.widget.LinearLayout;import android.widget.TextView;

public class MainActivity extends Activity{
 private SettingsStore st; private TextView status;
 @Override protected void onCreate(Bundle b){super.onCreate(b);st=new SettingsStore(this);ui();}
 @Override protected void onResume(){super.onResume();refresh();}
 private void ui(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,18,28,18);TextView t=new TextView(this);t.setText("Dustin Bot V2");t.setTextSize(30);t.setGravity(Gravity.CENTER);r.addView(t);status=new TextView(this);status.setTextSize(18);status.setPadding(0,14,0,14);r.addView(status);
  Button a=btn("เปิด Accessibility");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));r.addView(a);
  Button o=btn("เปิดปุ่มลอย BOT / STOP");o.setOnClickListener(v->{if(Settings.canDrawOverlays(this))startService(new Intent(this,BotOverlayService.class));else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));});r.addView(o);
  Button stop=btn("ปิดปุ่มลอย");stop.setOnClickListener(v->stopService(new Intent(this,BotOverlayService.class)));r.addView(stop);
  r.addView(label("ตั้งค่าปุ่มโจมตี (พิกัดหน้าจอ)"));EditText atk=new EditText(this);atk.setText(st.attackX()+","+st.attackY());atk.setHint("เช่น 900,1400");r.addView(atk);Button saveAtk=btn("บันทึกตำแหน่งปุ่มโจมตี");saveAtk.setOnClickListener(v->{int[] p=parse(atk.getText().toString());if(p!=null)st.setAttack(p[0],p[1]);});r.addView(saveAtk);
  r.addView(label("จุดเดินหลายจุด: x,y;x,y;..."));EditText pts=new EditText(this);pts.setText(st.points());r.addView(pts);Button savePts=btn("บันทึกจุดเดิน");savePts.setOnClickListener(v->st.setPoints(pts.getText().toString()));r.addView(savePts);
  TextView note=new TextView(this);note.setText("ระบบภาพ V2 ใช้ Screenshot จาก Accessibility เพื่อหา Monster/Item แบบสีโดยประมาณ ต้องปรับสี/พื้นที่ให้ตรงกับเกมก่อนใช้งานจริง\n\nไม่มี anti-cheat bypass และไม่แก้ client เกม");note.setTextSize(15);note.setPadding(0,18,0,0);r.addView(note);setContentView(r);}
 private TextView label(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(17);v.setPadding(0,14,0,5);return v;}
 private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setAllCaps(false);return b;}
 private int[] parse(String s){try{String[] a=s.trim().split(",");if(a.length!=2)return null;return new int[]{Integer.parseInt(a[0].trim()),Integer.parseInt(a[1].trim())};}catch(Exception e){return null;}}
 private void refresh(){if(status==null)return;boolean ov=Settings.canDrawOverlays(this),ac=isAccess();status.setText("สถานะ: Accessibility "+(ac?"พร้อม":"ยังไม่เปิด")+" | Overlay "+(ov?"พร้อม":"ยังไม่อนุญาต"));status.setTextColor(ac?Color.rgb(0,140,0):Color.rgb(190,90,0));}
 private boolean isAccess(){try{String e=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);if(e==null)return false;ComponentName x=new ComponentName(this,BotAccessibilityService.class);for(String s:e.split(":")){ComponentName c=ComponentName.unflattenFromString(s);if(x.equals(c))return true;}}catch(Throwable ignored){}return false;}
}
