package com.dustinbot.v2;

import android.content.Context;
import android.content.SharedPreferences;

public final class SettingsStore {
    private static final String P = "dustin_v2";
    private final SharedPreferences p;
    public SettingsStore(Context c) { p = c.getSharedPreferences(P, Context.MODE_PRIVATE); }
    public int attackX() { return p.getInt("attack_x", 900); }
    public int attackY() { return p.getInt("attack_y", 1400); }
    public int scanMs() { return p.getInt("scan_ms", 700); }
    public int walkMs() { return p.getInt("walk_ms", 900); }
    public int monsterR() { return p.getInt("monster_r", 220); }
    public int monsterG() { return p.getInt("monster_g", 70); }
    public int monsterB() { return p.getInt("monster_b", 70); }
    public int itemR() { return p.getInt("item_r", 245); }
    public int itemG() { return p.getInt("item_g", 200); }
    public int itemB() { return p.getInt("item_b", 40); }
    public String points() { return p.getString("points", "250,900;500,900;750,900;1000,900"); }
    public void setAttack(int x,int y){p.edit().putInt("attack_x",x).putInt("attack_y",y).apply();}
    public void setScanMs(int v){p.edit().putInt("scan_ms",Math.max(200,v)).apply();}
    public void setWalkMs(int v){p.edit().putInt("walk_ms",Math.max(200,v)).apply();}
    public void setPoints(String v){p.edit().putString("points",v).apply();}
}
