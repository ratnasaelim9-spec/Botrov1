package com.dustinbot.v2;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;
    @Override protected void onServiceConnected() {
        super.onServiceConnected(); instance=this;
        AccessibilityServiceInfo i=getServiceInfo();
        if(i!=null){i.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;i.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;i.notificationTimeout=100;i.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;setServiceInfo(i);}
        Toast.makeText(this,"Dustin Bot V2: Accessibility พร้อม",Toast.LENGTH_SHORT).show();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    public boolean tap(int x,int y){
        if(x<0||y<0)return false; Path p=new Path();p.moveTo(x,y);
        return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,70)).build(),null,null);
    }
    public interface ShotCallback { void onShot(Bitmap b); }
    public void screenshot(ShotCallback cb){
        if(Build.VERSION.SDK_INT<30){cb.onShot(null);return;}
        try { takeScreenshot(0,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult r){ Bitmap b=Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(),r.getColorSpace()); if(b!=null)b=b.copy(Bitmap.Config.ARGB_8888,false); r.getHardwareBuffer().close(); cb.onShot(b); }
            @Override public void onFailure(int e){cb.onShot(null);}
        }); } catch(Throwable t){cb.onShot(null);}
    }
}
