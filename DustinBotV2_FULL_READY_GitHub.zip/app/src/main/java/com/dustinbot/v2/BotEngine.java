package com.dustinbot.v2;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;

public final class BotEngine {
    public interface Listener { void log(String s); void state(String s); }
    private final SettingsStore settings; private final Handler h=new Handler(Looper.getMainLooper()); private final Listener l;
    private volatile boolean running=false; private int pointIndex=0; private List<int[]> points=new ArrayList<>();
    public BotEngine(SettingsStore s,Listener listener){settings=s;l=listener;loadPoints();}
    private void loadPoints(){points.clear();for(String p:settings.points().split(";")){String[] a=p.trim().split(",");if(a.length==2)try{points.add(new int[]{Integer.parseInt(a[0]),Integer.parseInt(a[1])});}catch(Exception ignored){}}}
    public boolean isRunning(){return running;}
    public void start(){if(running)return;running=true;l.state("BOT ทำงาน");l.log("เริ่ม BOT");loop();}
    public void stop(){running=false;h.removeCallbacksAndMessages(null);l.state("หยุดแล้ว");l.log("หยุด BOT");}
    private void loop(){if(!running)return; final BotAccessibilityService s=BotAccessibilityService.instance;if(s==null){l.log("Accessibility ไม่พร้อม");h.postDelayed(this::loop,1500);return;}
        l.state("กำลังสแกน Monster/Item");
        s.screenshot(new BotAccessibilityService.ShotCallback(){public void onShot(Bitmap b){if(!running)return; VisionEngine.Hit m=VisionEngine.findMonster(b,settings); if(m!=null){l.log("พบ Monster ที่ "+m.x+","+m.y);s.tap(m.x,m.y);h.postDelayed(()->s.tap(settings.attackX(),settings.attackY()),120);h.postDelayed(()->{if(b!=null)b.recycle();loop();},settings.scanMs());return;} VisionEngine.Hit it=VisionEngine.findItem(b,settings); if(it!=null){l.log("พบ Item ที่ "+it.x+","+it.y);s.tap(it.x,it.y);h.postDelayed(()->{if(b!=null)b.recycle();loop();},settings.scanMs());return;} if(b!=null)b.recycle(); walk(s);}});
    }
    private void walk(BotAccessibilityService s){if(points.isEmpty()){l.log("ยังไม่มีจุดเดิน");h.postDelayed(this::loop,settings.scanMs());return;}int[] p=points.get(pointIndex++%points.size());l.log("เดินไป "+p[0]+","+p[1]);s.tap(p[0],p[1]);h.postDelayed(this::loop,settings.walkMs());}
}
