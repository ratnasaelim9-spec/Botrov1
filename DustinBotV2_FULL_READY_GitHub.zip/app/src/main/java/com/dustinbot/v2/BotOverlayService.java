package com.dustinbot.v2;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BotOverlayService extends Service {
    private WindowManager wm; private LinearLayout box; private BotEngine engine;
    @Override public void onCreate(){super.onCreate(); if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"ยังไม่ได้อนุญาต Overlay",Toast.LENGTH_SHORT).show();stopSelf();return;} engine=new BotEngine(new SettingsStore(this),new BotEngine.Listener(){public void log(String s){last=s;}public void state(String s){state=s;}}); create();}
    private String state="พร้อม",last="";
    private void create(){try{wm=(WindowManager)getSystemService(WINDOW_SERVICE);box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,6,10,6);box.setBackgroundColor(Color.rgb(35,35,35));TextView title=new TextView(this);title.setText("Dustin Bot V2");title.setTextColor(Color.WHITE);title.setTextSize(17);Button bot=btn("BOT");Button stop=btn("STOP");Button test=btn("แตะโจมตี");Button close=btn("ปิดปุ่มลอย");bot.setOnClickListener(v->engine.start());stop.setOnClickListener(v->engine.stop());test.setOnClickListener(v->{BotAccessibilityService s=BotAccessibilityService.instance;if(s==null)Toast.makeText(this,"Accessibility ยังไม่ทำงาน",Toast.LENGTH_SHORT).show();else s.tap(new SettingsStore(this).attackX(),new SettingsStore(this).attackY());});close.setOnClickListener(v->stopSelf());box.addView(title);box.addView(bot);box.addView(stop);box.addView(test);box.addView(close);WindowManager.LayoutParams lp=new WindowManager.LayoutParams(300,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=12;lp.y=170;wm.addView(box,lp);}catch(Throwable t){stopSelf();}}
    private Button btn(String t){Button b=new Button(this);b.setText(t);b.setTextSize(17);b.setAllCaps(false);b.setMinHeight(0);return b;}
    @Override public void onDestroy(){if(engine!=null)engine.stop();try{if(wm!=null&&box!=null)wm.removeView(box);}catch(Throwable ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
