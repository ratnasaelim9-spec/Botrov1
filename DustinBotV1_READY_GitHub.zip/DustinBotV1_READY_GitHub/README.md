# DustinBotV1

Android Accessibility bot base project.

## Current V1
- Accessibility Service
- Overlay control
- BOT / STOP / แตะทดสอบ
- Gesture tap test
- GitHub Actions debug APK build

## Next development phase
1. Waypoint walking
2. Screen capture / visual detection
3. Monster detection
4. Attack control
5. Loot detection and pickup
6. Safety stop / recovery logic
