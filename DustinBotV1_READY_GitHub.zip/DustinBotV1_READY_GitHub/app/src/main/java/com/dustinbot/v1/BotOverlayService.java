package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BotOverlayService extends Service {

    private WindowManager wm;
    private View overlay;

    @Override
    public void onCreate() {
        super.onCreate();

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(10, 10, 10, 10);
        box.setBackgroundColor(Color.rgb(55, 55, 55));

        Button bot = new Button(this);
        bot.setText("▶ BOT");
        bot.setOnClickListener(v -> {
            // Next phase: start walk -> detect -> attack -> loot loop.
        });
        box.addView(bot);

        Button stop = new Button(this);
        stop.setText("■ STOP");
        stop.setOnClickListener(v -> {
            // Emergency stop for all future automation loops.
        });
        box.addView(stop);

        Button test = new Button(this);
        test.setText("แตะทดสอบ");
        test.setOnClickListener(v -> {
            // Test tap near screen center. Used only to verify Accessibility gesture.
            if (BotAccessibilityService.isReady()) {
                BotAccessibilityService.tap(600, 700);
            }
        });
        box.addView(test);

        TextView ready = new TextView(this);
        ready.setText("พร้อม");
        ready.setTextColor(Color.WHITE);
        ready.setTextSize(16);
        box.addView(ready);

        overlay = box;

        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;

        wm.addView(overlay, params);
    }

    @Override
    public void onDestroy() {
        if (overlay != null) wm.removeView(overlay);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
