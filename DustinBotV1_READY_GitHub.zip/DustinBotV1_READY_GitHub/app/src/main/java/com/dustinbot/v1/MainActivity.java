package com.dustinbot.v1;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Dustin Bot V1");
        title.setTextSize(28);
        title.setTextColor(Color.DKGRAY);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Dustin RO automation helper\\n\\nเริ่มจากระบบพื้นฐาน: Accessibility + ปุ่มลอย + แตะทดสอบ");
        desc.setTextSize(17);
        desc.setPadding(0, 24, 0, 24);
        root.addView(desc);

        Button accessibility = new Button(this);
        accessibility.setText("เปิด ACCESSIBILITY");
        accessibility.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(i);
        });
        root.addView(accessibility);

        Button overlay = new Button(this);
        overlay.setText("เปิดปุ่มลอย");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, BotOverlayService.class));
            }
        });
        root.addView(overlay);

        status = new TextView(this);
        status.setText("พร้อม");
        status.setTextSize(18);
        status.setPadding(0, 24, 0, 0);
        root.addView(status);

        setContentView(root);
    }
}
