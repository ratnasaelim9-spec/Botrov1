package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22,22,22,22);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Dustin Bot V1.4");
        title.setTextSize(30);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nฐานระบบบอท\n\n1. Accessibility\n2. ปุ่มลอย BOT / STOP\n3. ทดสอบแตะหน้าจอ\n\nขั้นต่อไป: เดิน → หา Monster → ตี → เก็บของ");
        info.setTextSize(19);
        info.setTextColor(Color.DKGRAY);
        root.addView(info);

        status = new TextView(this);
        status.setTextSize(20);
        status.setPadding(0,15,0,15);
        root.addView(status);

        Button access = button("เปิด ACCESSIBILITY");
        access.setOnClickListener(v -> startActivity(
                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button overlay = button("เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
            startService(new Intent(this, BotOverlayService.class));
            updateStatus();
        });
        root.addView(overlay);

        Button stop = button("ปิดปุ่มลอย");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, BotOverlayService.class));
            updateStatus();
        });
        root.addView(stop);

        setContentView(root);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 62);
        p.setMargins(0,7,0,7);
        b.setLayoutParams(p);
        return b;
    }

    private void updateStatus() {
        boolean a11y = BotAccessibilityService.isRunning();
        boolean overlay = Settings.canDrawOverlays(this);
        status.setText("สถานะ: Accessibility " +
                (a11y ? "พร้อม" : "ยังไม่เปิด") +
                " | Overlay " + (overlay ? "พร้อม" : "ยังไม่อนุญาต"));
        status.setTextColor(a11y ? Color.rgb(0,140,0) : Color.rgb(190,90,0));
    }
}
