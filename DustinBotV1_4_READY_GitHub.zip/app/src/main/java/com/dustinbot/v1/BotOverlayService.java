package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class BotOverlayService extends Service {
    private WindowManager wm;
    private LinearLayout overlay;

    private static final float TEST_X = 600f;
    private static final float TEST_Y = 700f;

    @Override
    public void onCreate() {
        super.onCreate();

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(12,12,12,12);
        overlay.setBackgroundColor(Color.argb(225,45,45,45));

        Button bot = makeButton("BOT");
        Button stop = makeButton("STOP");
        Button test = makeButton("แตะทดสอบ");

        bot.setOnClickListener(v ->
                Toast.makeText(this,
                        "BOT: ระบบหลักยังอยู่ระหว่างสร้าง",
                        Toast.LENGTH_SHORT).show());

        stop.setOnClickListener(v ->
                Toast.makeText(this, "STOP",
                        Toast.LENGTH_SHORT).show());

        test.setOnClickListener(v -> {
            if (!BotAccessibilityService.isRunning()) {
                Toast.makeText(this,
                        "Accessibility ยังไม่เชื่อมต่อ",
                        Toast.LENGTH_LONG).show();
                return;
            }

            boolean sent = BotAccessibilityService.tap(TEST_X, TEST_Y);
            Toast.makeText(this,
                    sent ? "ส่งแตะ: 600,700" : "ส่งคำสั่งแตะไม่สำเร็จ",
                    Toast.LENGTH_SHORT).show();
        });

        overlay.addView(bot);
        overlay.addView(stop);
        overlay.addView(test);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                190,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = 10;
        lp.y = 180;

        wm.addView(overlay, lp);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setAllCaps(false);
        b.setTextColor(Color.BLACK);
        b.setBackgroundColor(Color.LTGRAY);
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(166,64);
        p.setMargins(0,5,0,5);
        b.setLayoutParams(p);
        return b;
    }

    @Override
    public void onDestroy() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        }
        overlay = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
