# DustinBot V1.3

Clean Android Java base for Dustin RO automation.

V1.3 goal:
- Stable launch screen
- Accessibility service
- Overlay controls
- Manual test tap
- Clean Gradle/Kotlin dependency setup

No anti-cheat bypass or client modification is included.

Next development phase:
walking, monster detection, attack, loot detection and collection, using permitted Android automation.
