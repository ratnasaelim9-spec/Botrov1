package com.dustinbot.v1;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);
        root.setGravity(Gravity.TOP);

        TextView title = new TextView(this);
        title.setText("Dustin Bot V1.3");
        title.setTextSize(28);
        title.setTextColor(Color.BLACK);
        title.setPadding(0, 0, 0, 24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("ฐานระบบบอท\n\n1. Accessibility\n2. ปุ่มลอย BOT / STOP\n3. ทดสอบแตะหน้าจอ\n\nขั้นต่อไปจะเพิ่ม เดิน → หา Monster → ตี → เก็บของ");
        info.setTextSize(17);
        info.setTextColor(Color.DKGRAY);
        root.addView(info);

        status = new TextView(this);
        status.setText("\nสถานะ: พร้อมใช้งาน");
        status.setTextSize(17);
        status.setTextColor(Color.rgb(0, 120, 0));
        root.addView(status);

        Button accessibility = new Button(this);
        accessibility.setText("เปิด ACCESSIBILITY");
        accessibility.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(i);
        });
        root.addView(accessibility);

        Button overlay = new Button(this);
        overlay.setText("เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, BotOverlayService.class));
                status.setText("\nสถานะ: เปิดปุ่มลอยแล้ว");
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        root.addView(overlay);

        Button stopOverlay = new Button(this);
        stopOverlay.setText("ปิดปุ่มลอย");
        stopOverlay.setOnClickListener(v -> {
            stopService(new Intent(this, BotOverlayService.class));
            status.setText("\nสถานะ: ปิดปุ่มลอยแล้ว");
        });
        root.addView(stopOverlay);

        setContentView(root);
    }
}
