package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class BotOverlayService extends Service {

    private WindowManager wm;
    private View overlay;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8, 8, 8, 8);
        box.setBackgroundColor(Color.argb(225, 35, 35, 35));

        Button bot = new Button(this);
        bot.setText("BOT");
        bot.setOnClickListener(v -> {
            running = true;
            Toast.makeText(this, "BOT: เริ่มทำงาน", Toast.LENGTH_SHORT).show();
        });

        Button stop = new Button(this);
        stop.setText("STOP");
        stop.setOnClickListener(v -> {
            running = false;
            Toast.makeText(this, "BOT: หยุด", Toast.LENGTH_SHORT).show();
        });

        Button test = new Button(this);
        test.setText("แตะทดสอบ");
        test.setOnClickListener(v -> {
            boolean ok = BotAccessibilityService.tap(600, 700);
            Toast.makeText(this,
                    ok ? "ส่งคำสั่งแตะแล้ว" : "Accessibility ยังไม่พร้อม",
                    Toast.LENGTH_SHORT).show();
        });

        box.addView(bot);
        box.addView(stop);
        box.addView(test);

        overlay = box;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 20;
        lp.y = 160;

        wm.addView(overlay, lp);
    }

    @Override
    public void onDestroy() {
        if (wm != null && overlay != null) {
            try {
                wm.removeView(overlay);
            } catch (Exception ignored) {
            }
        }
        overlay = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
