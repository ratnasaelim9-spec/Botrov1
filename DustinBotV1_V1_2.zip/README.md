# Dustin Bot V1.2

V1.2 is a first working test stage for a server that permits automation.

Functions:
- Android Accessibility tap/gesture control
- 3-point screen-coordinate walking loop
- attack tap after movement
- MediaProjection screen capture
- basic red-pixel target signal

How to use:
1. Install APK.
2. Enable Accessibility.
3. Open the floating BOT panel.
4. Allow screen capture when requested.
5. Use START to run the test loop.
6. STOP immediately if coordinates are wrong.

The detector is a lightweight visual heuristic, not a trained monster detector. It may produce false positives. V1.3 should add calibrated monster templates/regions and loot detection.

No anti-cheat bypass, client modification, or detection evasion is included.
