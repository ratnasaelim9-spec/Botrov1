package com.dustinbot.v1;

import android.app.Application;

public class BotApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        BotController.init(this);
    }
}
