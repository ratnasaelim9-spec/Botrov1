package com.dustinbot.v1;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE="result_code";
    public static final String EXTRA_DATA="result_data";

    MediaProjection projection;
    VirtualDisplay display;
    ImageReader reader;
    Handler handler=new Handler(Looper.getMainLooper());

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        createNotification();
        if(intent!=null && intent.hasExtra(EXTRA_DATA)){
            int resultCode=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED);
            Intent data=intent.getParcelableExtra(EXTRA_DATA);
            if(resultCode==Activity.RESULT_OK && data!=null) startCapture(resultCode,data);
        }
        return START_NOT_STICKY;
    }

    void createNotification(){
        String channel="dustin_capture";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            nm.createNotificationChannel(new NotificationChannel(channel,"Dustin Bot","low"));
        }
        Notification n=new Notification.Builder(this,Build.VERSION.SDK_INT>=26?channel:null)
                .setContentTitle("Dustin Bot")
                .setContentText("กำลังตรวจภาพหน้าจอ")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
        startForeground(901,n);
    }

    void startCapture(int resultCode,Intent data){
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(resultCode,data);
        int w=getResources().getDisplayMetrics().widthPixels;
        int h=getResources().getDisplayMetrics().heightPixels;
        int dpi=getResources().getDisplayMetrics().densityDpi;

        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(r -> analyze(r.acquireLatestImage()),handler);
        display=projection.createVirtualDisplay("DustinBotCapture",w,h,dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),null,handler);
    }

    void analyze(Image image){
        if(image==null) return;
        try{
            Image.Plane plane=image.getPlanes()[0];
            ByteBuffer b=plane.getBuffer();
            int ps=plane.getPixelStride(), rs=plane.getRowStride();
            int w=image.getWidth(), h=image.getHeight();
            int redHits=0, samples=0;

            // Lightweight heuristic: search the central game area for strongly red pixels.
            for(int y=h/5;y<h*4/5;y+=10){
                for(int x=w/10;x<w*9/10;x+=10){
                    int pos=y*rs+x*ps;
                    if(pos+3>=b.capacity()) continue;
                    int rr=b.get(pos)&255, gg=b.get(pos+1)&255, bb=b.get(pos+2)&255;
                    if(rr>180 && rr>gg*1.4 && rr>bb*1.4) redHits++;
                    samples++;
                }
            }
            if(redHits>Math.max(15,samples/220)) BotController.onTargetSignal();
        }catch(Exception ignored){} finally { image.close(); }
    }

    @Override public void onDestroy(){
        if(display!=null) display.release();
        if(reader!=null) reader.close();
        if(projection!=null) projection.stop();
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
