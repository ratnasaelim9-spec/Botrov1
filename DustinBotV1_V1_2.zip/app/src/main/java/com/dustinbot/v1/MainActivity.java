package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    static final int REQ_CAPTURE = 7001;
    TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        BotController.init(this);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("Dustin Bot V1\nV1.2 Walk + Monster");
        title.setTextSize(27);
        title.setTextColor(Color.rgb(0,75,135));
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        status = new TextView(this);
        status.setText("\nสถานะ: พร้อมใช้งาน\n\nV1.2: เดินตามจุด + สัญญาณตรวจ Monster แบบพื้นฐาน");
        status.setTextSize(18);
        box.addView(status);

        Button acc = new Button(this);
        acc.setText("1. เปิด ACCESSIBILITY");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(acc);

        Button overlay = new Button(this);
        overlay.setText("2. เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> {
            startService(new Intent(this, BotOverlayService.class));
            status.setText("สถานะ: เปิดปุ่มลอยแล้ว ✓");
        });
        box.addView(overlay);

        Button cap = new Button(this);
        cap.setText("3. อนุญาตจับหน้าจอ");
        cap.setOnClickListener(v -> {
            MediaProjectionManager m =
                (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        box.addView(cap);

        Button test = new Button(this);
        test.setText("แตะทดสอบ (600,700)");
        test.setOnClickListener(v -> {
            if (BotAccessibilityService.instance != null) {
                BotAccessibilityService.instance.tap(600,700);
                status.setText("แตะทดสอบแล้ว ✓");
            } else status.setText("กรุณาเปิด Accessibility ก่อน");
        });
        box.addView(test);

        setContentView(box);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent s = new Intent(this, ScreenCaptureService.class);
                s.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
                s.putExtra(ScreenCaptureService.EXTRA_DATA, data);
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(s);
                else startService(s);
                status.setText("สถานะ: อนุญาตจับหน้าจอแล้ว ✓");
            } else status.setText("ไม่ได้อนุญาตจับหน้าจอ");
        }
    }
}
