package com.dustinbot.v1;

import android.content.Context;
import android.graphics.Point;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class BotController {
    static final Handler h = new Handler(Looper.getMainLooper());
    static boolean running = false;
    static final Point[] wp = {new Point(400,900),new Point(800,900),new Point(1100,900)};
    static final boolean[] saved = {true,true,true};
    static final Point attack = new Point(1290,760);
    static int current = 0;
    static Context app;

    public static void init(Context c){ app=c.getApplicationContext(); }

    public static void saveWaypoint(int n) {
        // V1.2 uses safe preset screen coordinates. V1.3 will add on-screen coordinate capture.
        int x = 350 + (n-1)*350;
        int y = 900;
        wp[n-1].set(x,y);
        saved[n-1]=true;
        toast("จุด "+n+" = "+x+","+y);
    }

    public static void saveAttackPoint() {
        attack.set(1290,760);
        toast("ปุ่มโจมตี = 1290,760");
    }

    public static void start(Context c) {
        init(c);
        if(running) return;
        if(BotAccessibilityService.instance==null){
            toast("กรุณาเปิด Accessibility");
            return;
        }
        running=true;
        current=0;
        loop();
        toast("BOT START");
    }

    public static void stop(){
        running=false;
        h.removeCallbacksAndMessages(null);
        toast("BOT STOP");
    }

    static void loop(){
        if(!running || BotAccessibilityService.instance==null) return;
        Point p=wp[current];
        BotAccessibilityService.instance.tap(p.x,p.y);

        h.postDelayed(() -> {
            if(!running || BotAccessibilityService.instance==null) return;
            // Attack after moving to the waypoint.
            BotAccessibilityService.instance.tap(attack.x,attack.y);
            current=(current+1)%wp.length;
            h.postDelayed(BotController::loop,1800);
        },900);
    }

    public static void onTargetSignal(){
        if(!running || BotAccessibilityService.instance==null) return;
        BotAccessibilityService.instance.tap(attack.x,attack.y);
    }

    static void toast(String s){
        if(app!=null) Toast.makeText(app,s,Toast.LENGTH_SHORT).show();
    }
}
