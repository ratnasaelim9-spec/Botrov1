package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BotOverlayService extends Service {
    WindowManager wm;
    View panel;
    boolean running = false;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8,8,8,8);
        box.setBackgroundColor(Color.argb(235,30,30,30));

        TextView title = new TextView(this);
        title.setText("DUSTIN BOT 1.2");
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        Button start = new Button(this);
        start.setText("START");
        start.setOnClickListener(v -> {
            running = true;
            BotController.start(this);
        });
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("STOP");
        stop.setOnClickListener(v -> {
            running = false;
            BotController.stop();
        });
        box.addView(stop);

        Button p1 = new Button(this);
        p1.setText("จุด 1");
        p1.setOnClickListener(v -> BotController.saveWaypoint(1));
        box.addView(p1);

        Button p2 = new Button(this);
        p2.setText("จุด 2");
        p2.setOnClickListener(v -> BotController.saveWaypoint(2));
        box.addView(p2);

        Button p3 = new Button(this);
        p3.setText("จุด 3");
        p3.setOnClickListener(v -> BotController.saveWaypoint(3));
        box.addView(p3);

        Button attack = new Button(this);
        attack.setText("ตั้งปุ่มโจมตี");
        attack.setOnClickListener(v -> BotController.saveAttackPoint());
        box.addView(attack);

        panel = box;

        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = 20; lp.y = 180;

        wm.addView(panel, lp);
    }

    @Override public void onDestroy() {
        BotController.stop();
        if (panel != null) wm.removeView(panel);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
