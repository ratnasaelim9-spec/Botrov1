package com.dustinbot.v1;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import java.util.Locale;

public class BotOverlayService extends Service {
    private static BotOverlayService instance;
    private WindowManager wm;
    private LinearLayout box;
    private TextView state;
    private final Handler handler = new Handler();
    private boolean running;
    private long x=600,y=700,interval=1200,count;

    public static void start(Context c){ c.startService(new Intent(c,BotOverlayService.class)); }
    public static void stop(Context c){ c.stopService(new Intent(c,BotOverlayService.class)); }
    public static void setConfig(long nx,long ny,long ni){
        if(instance!=null){instance.x=nx;instance.y=ny;instance.interval=Math.max(100,ni);}
    }

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}

    @Override public void onCreate(){
        super.onCreate(); instance=this;
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8),dp(8),dp(8),dp(8));
        box.setBackgroundColor(Color.rgb(45,45,45));

        TextView bot=button("BOT"), stop=button("STOP"), test=button("แตะ 1 ครั้ง");
        state=new TextView(this); state.setTextColor(Color.WHITE); state.setTextSize(12);
        state.setGravity(Gravity.CENTER); state.setText("หยุด");

        bot.setOnClickListener(v->startBot());
        stop.setOnClickListener(v->stopBot());
        test.setOnClickListener(v->{
            boolean ok=BotAccessibilityService.tap(x,y);
            state.setText(ok ? "แตะแล้ว "+x+","+y : "แตะไม่สำเร็จ");
        });

        box.addView(bot);box.addView(stop);box.addView(test);box.addView(state);

        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(
                dp(190),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.LEFT; lp.x=dp(10);lp.y=dp(180);
        wm.addView(box,lp);
    }

    private TextView button(String s){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(18);v.setTextColor(Color.BLACK);
        v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(225,225,225));
        bg.setCornerRadius(dp(7));v.setBackground(bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(174),dp(54));
        p.setMargins(0,dp(4),0,dp(4));v.setLayoutParams(p);return v;
    }

    private void startBot(){
        if(!BotAccessibilityService.isRunning()){state.setText("เปิด Accessibility ก่อน");return;}
        if(running)return; running=true; state.setText("กำลังแตะ "+x+","+y); handler.post(tick);
    }

    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(!running)return;
            if(BotAccessibilityService.tap(x,y)){
                count++;
                state.setText(String.format(Locale.US,"ทำงาน %d ครั้ง\n%d,%d / %dms",count,x,y,interval));
            }else state.setText("ส่งแตะไม่สำเร็จ");
            handler.postDelayed(this,Math.max(100,interval));
        }
    };

    private void stopBot(){running=false;handler.removeCallbacks(tick);state.setText("หยุด");}

    @Override public void onDestroy(){
        running=false;handler.removeCallbacks(tick);
        if(wm!=null&&box!=null)try{wm.removeView(box);}catch(Exception ignored){}
        instance=null;super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
