package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private TextView status;
    private EditText xEdit, yEdit, intervalEdit;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView button(String s) {
        TextView v = text(s, 18, Color.BLACK);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(225,225,225));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.rgb(175,175,175));
        v.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56));
        p.setMargins(0, dp(5), 0, dp(5));
        v.setLayoutParams(p);
        return v;
    }

    private EditText field(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(18);
        e.setTextColor(Color.BLACK);
        e.setSingleLine(true);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setPadding(dp(12),0,dp(12),0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setStroke(dp(1), Color.GRAY);
        bg.setCornerRadius(dp(6));
        e.setBackground(bg);
        e.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 1f));
        return e;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(18));
        root.setBackgroundColor(Color.WHITE);

        TextView title = text("Dustin Bot V1.6",30,Color.BLACK);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(55)));

        root.addView(text("โหมดทดสอบควบคุมหน้าจอจริง\nBOT = แตะพิกัดซ้ำ | STOP = หยุดทันที",
                18, Color.DKGRAY),new LinearLayout.LayoutParams(-1,dp(80)));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(text("X",18,Color.BLACK),new LinearLayout.LayoutParams(dp(35),dp(52)));
        xEdit = field("600"); row1.addView(xEdit);
        row1.addView(text("   Y",18,Color.BLACK),new LinearLayout.LayoutParams(dp(55),dp(52)));
        yEdit = field("700"); row1.addView(yEdit);
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(text("ระยะเวลาแตะ (ms)",17,Color.BLACK),
                new LinearLayout.LayoutParams(0,dp(52),1f));
        intervalEdit = field("1200");
        row2.addView(intervalEdit,new LinearLayout.LayoutParams(dp(130),dp(52)));
        root.addView(row2);

        status = text("สถานะ: กำลังตรวจสอบ Accessibility",18,Color.DKGRAY);
        status.setPadding(0,dp(12),0,dp(12));
        root.addView(status);

        TextView access = button("เปิด Accessibility");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        TextView overlay = button("เปิดปุ่มลอย BOT / STOP");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else {
                BotOverlayService.start(this);
                updateStatus();
            }
        });
        root.addView(overlay);

        TextView stop = button("ปิดปุ่มลอย");
        stop.setOnClickListener(v -> {
            BotOverlayService.stop(this);
            updateStatus();
        });
        root.addView(stop);

        TextView save = button("ใช้พิกัด/เวลาในปุ่มลอย");
        save.setOnClickListener(v -> {
            BotOverlayService.setConfig(parse(xEdit,600), parse(yEdit,700), parse(intervalEdit,1200));
            status.setText("บันทึกแล้ว: X="+parse(xEdit,600)+" Y="+parse(yEdit,700)+
                    " ทุก "+parse(intervalEdit,1200)+" ms");
        });
        root.addView(save);
        setContentView(root);
        updateStatus();
    }

    private long parse(EditText e,long def) {
        try { return Long.parseLong(e.getText().toString().trim()); }
        catch(Exception ex) { return def; }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText("สถานะ: Accessibility " +
                (BotAccessibilityService.isRunning() ? "พร้อม" : "ยังไม่เปิด") +
                " | Overlay " +
                (Settings.canDrawOverlays(this) ? "พร้อม" : "ยังไม่อนุญาต"));
    }
}
