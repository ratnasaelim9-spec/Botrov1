# Dustin Bot V2 FULL
ระบบรวมใน APK เดียว: Accessibility gesture, Overlay, MediaProjection screen capture,
Monster/Item template matching, จุดเดินหลายจุด และลูปตรวจ-ตี-เก็บ-เดิน

ต้องใช้กับเกม/เซิร์ฟเวอร์ที่อนุญาต automation เท่านั้น
ไม่มี anti-cheat bypass และไม่มีการแก้ไข client
