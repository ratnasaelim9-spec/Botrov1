package com.dustinbot.full;

import android.content.Context;
import android.content.SharedPreferences;

public final class Config {
    private static final String P="bot_config";
    private static SharedPreferences p(Context c){ return c.getSharedPreferences(P, Context.MODE_PRIVATE); }

    public static int get(Context c,String k,int d){ return p(c).getInt(k,d); }
    public static void put(Context c,String k,int v){ p(c).edit().putInt(k,v).apply(); }
    public static String get(Context c,String k,String d){ return p(c).getString(k,d); }
    public static void put(Context c,String k,String v){ p(c).edit().putString(k,v).apply(); }
}
