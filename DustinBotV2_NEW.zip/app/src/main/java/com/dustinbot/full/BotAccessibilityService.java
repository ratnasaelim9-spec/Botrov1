package com.dustinbot.full;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;

    @Override public void onServiceConnected(){
        super.onServiceConnected();
        instance=this;
        AccessibilityServiceInfo i=getServiceInfo();
        if(i!=null){
            i.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            i.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
            i.notificationTimeout=100;
            setServiceInfo(i);
        }
        Toast.makeText(this,"Dustin Bot: Accessibility พร้อม",Toast.LENGTH_SHORT).show();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){
        if(instance==this) instance=null;
        super.onDestroy();
    }
    public boolean tap(float x,float y){
        if(x<0||y<0) return false;
        Path path=new Path(); path.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path,0,60)).build();
        return dispatchGesture(g,null,null);
    }
}
