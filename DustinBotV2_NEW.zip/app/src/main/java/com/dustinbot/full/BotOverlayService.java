package com.dustinbot.full;

import android.app.Service;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;
import android.content.SharedPreferences;

public class BotOverlayService extends Service {
    private WindowManager wm; private View overlay; private Handler h=new Handler(Looper.getMainLooper());
    private volatile boolean running=false; private int waypointIndex=0;
    private final Runnable loop=new Runnable(){ public void run(){ if(!running)return; tick(); }};

    @Override public void onCreate(){super.onCreate();create();}
    private Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setAllCaps(false);
        return b;
    }
    private void create(){
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8,8,8,8); box.setBackgroundColor(Color.rgb(45,45,45));
        Button bot=btn("BOT"), stop=btn("STOP"), test=btn("แตะทดสอบ"), cap=btn("จับภาพ");
        TextView s=new TextView(this); s.setTextColor(Color.WHITE); s.setText("พร้อม"); s.setTextSize(14);
        bot.setOnClickListener(v->startBot(s)); stop.setOnClickListener(v->stopBot(s));
        test.setOnClickListener(v->tapAttack());
        cap.setOnClickListener(v->Toast.makeText(this,"หน้าจอถูกจับภาพแล้ว",Toast.LENGTH_SHORT).show());
        box.addView(bot);box.addView(stop);box.addView(test);box.addView(cap);box.addView(s);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(360,-2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;lp.x=12;lp.y=180;
        try{wm.addView(box,lp);overlay=box;}catch(Throwable t){stopSelf();}
    }
    private void startBot(TextView status){
        if(BotAccessibilityService.instance==null){status.setText("Accessibility ยังไม่ทำงาน");return;}
        if(CaptureService.latest.get()==null){status.setText("ยังไม่มีภาพหน้าจอ");return;}
        running=true;waypointIndex=0;status.setText("BOT กำลังทำงาน");h.removeCallbacks(loop);h.post(loop);
    }
    private void stopBot(TextView status){running=false;h.removeCallbacks(loop);status.setText("หยุดแล้ว");}
    private void tap(int x,int y){
        BotAccessibilityService s=BotAccessibilityService.instance;
        if(s!=null)s.tap(x,y);
    }
    private void tapAttack(){
        int x=Config.get(this,"attackX",1290),y=Config.get(this,"attackY",760);tap(x,y);
    }
    private void tick(){
        try{
            Bitmap screen=CaptureService.latest.get();
            if(screen==null){h.postDelayed(loop,1000);return;}
            Bitmap mt=loadTemplate("monster");
            Bitmap it=loadTemplate("item");
            Rect mr=TemplateMatcher.find(screen,mt,Config.get(this,"monsterThreshold",78)/100f);
            if(mr!=null){
                tap(mr.centerX(),mr.centerY());
                tapAttack();
                h.postDelayed(loop,Config.get(this,"attackInterval",700));
                return;
            }
            Rect ir=TemplateMatcher.find(screen,it,Config.get(this,"itemThreshold",72)/100f);
            if(ir!=null){
                tap(ir.centerX(),ir.centerY());
                h.postDelayed(loop,300);
                return;
            }
            int[][] wp=waypoints();
            if(wp.length>0){
                int[] p=wp[waypointIndex++%wp.length];
                tap(p[0],p[1]);
                h.postDelayed(loop,Config.get(this,"walkDelay",1200));
            }else{
                tapAttack();
                h.postDelayed(loop,Config.get(this,"scanDelay",800));
            }
        }catch(Throwable t){h.postDelayed(loop,1200);}
    }
    private Bitmap loadTemplate(String name){
        String path=getFilesDir()+"/"+name+".png";
        return BitmapFactory.decodeFile(path);
    }
    private int[][] waypoints(){
        String raw=Config.get(this,"waypoints","");
        if(raw.trim().isEmpty())return new int[0][0];
        ArrayList<int[]> a=new ArrayList<>();
        for(String part:raw.split(";")){
            String[] q=part.trim().split(",");
            if(q.length==2)try{a.add(new int[]{Integer.parseInt(q[0]),Integer.parseInt(q[1])});}catch(Exception e){}
        }
        return a.toArray(new int[0][0]);
    }
    @Override public void onDestroy(){running=false;h.removeCallbacks(loop);try{if(wm!=null&&overlay!=null)wm.removeView(overlay);}catch(Throwable ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
