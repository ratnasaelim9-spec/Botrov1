package com.dustinbot.full;

import android.graphics.Bitmap;
import android.graphics.Rect;

public final class TemplateMatcher {
    public static Rect find(Bitmap screen, Bitmap templ, float threshold){
        if(screen==null||templ==null||screen.isRecycled()||templ.isRecycled())return null;
        int tw=templ.getWidth(), th=templ.getHeight();
        if(tw<4||th<4||tw>screen.getWidth()||th>screen.getHeight())return null;

        // Coarse normalized color-distance matching. Samples every 4 px first.
        int step=4, sx=screen.getWidth(), sy=screen.getHeight();
        long best=Long.MAX_VALUE; int bx=-1,by=-1;
        int maxX=sx-tw, maxY=sy-th;
        int samplesX=Math.max(1,tw/step), samplesY=Math.max(1,th/step);
        int count=samplesX*samplesY;
        int[] tp=new int[samplesX*samplesY];
        int k=0;
        for(int y=0;y<th;y+=step) for(int x=0;x<tw;x+=step)
            tp[k++]=templ.getPixel(x,y);

        for(int y=0;y<=maxY;y+=step){
            for(int x=0;x<=maxX;x+=step){
                long sum=0; k=0;
                for(int yy=0;yy<th;yy+=step){
                    for(int xx=0;xx<tw;xx+=step){
                        int a=screen.getPixel(x+xx,y+yy), b=tp[k++];
                        int ar=(a>>16)&255, ag=(a>>8)&255, ab=a&255;
                        int br=(b>>16)&255, bg=(b>>8)&255, bb=b&255;
                        sum += Math.abs(ar-br)+Math.abs(ag-bg)+Math.abs(ab-bb);
                    }
                }
                long avg=sum/(long)count;
                if(avg<best){best=avg;bx=x;by=y;}
            }
        }
        long maxErr=(long)(1f-threshold)*765L;
        if(bx<0 || best>maxErr) return null;

        // Local refinement around the coarse result.
        int rx=Math.max(0,bx-step*2), ry=Math.max(0,by-step*2);
        int ex=Math.min(maxX,bx+step*2), ey=Math.min(maxY,by+step*2);
        long best2=best; int fx=bx,fy=by;
        for(int y=ry;y<=ey;y++) for(int x=rx;x<=ex;x++){
            long sum=0; int n=0;
            for(int yy=0;yy<th;yy+=Math.max(2,step)){
                for(int xx=0;xx<tw;xx+=Math.max(2,step)){
                    int a=screen.getPixel(x+xx,y+yy), b=templ.getPixel(xx,yy);
                    sum+=Math.abs(((a>>16)&255)-((b>>16)&255));
                    sum+=Math.abs(((a>>8)&255)-((b>>8)&255));
                    sum+=Math.abs((a&255)-(b&255)); n++;
                }
            }
            long avg=sum/n;
            if(avg<best2){best2=avg;fx=x;fy=y;}
        }
        if(best2>maxErr)return null;
        return new Rect(fx,fy,fx+tw,fy+th);
    }
}
