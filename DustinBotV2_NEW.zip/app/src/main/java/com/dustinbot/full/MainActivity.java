package com.dustinbot.full;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE=7001;
    private EditText attackX,attackY,waypoints,walkDelay,attackDelay,scanDelay;
    private EditText mx,my,mw,mh,ix,iy,iw,ih;
    private TextView status;

    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    @Override public void onResume(){super.onResume();if(status!=null)refresh();}

    private EditText field(String hint,String value){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(17);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        return e;
    }
    private Button button(String text){
        Button b=new Button(this);b.setText(text);b.setTextSize(18);b.setAllCaps(false);return b;
    }
    private TextView label(String t){
        TextView v=new TextView(this);v.setText(t);v.setTextSize(19);v.setTextColor(Color.DKGRAY);v.setPadding(0,18,0,4);return v;
    }
    private void addPair(LinearLayout root, EditText a, EditText b){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(a,new LinearLayout.LayoutParams(0,-2,1));row.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(row);
    }
    private void build(){
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,20,24,30);
        TextView title=label("Dustin Bot V2 — Full");title.setTextSize(30);title.setTextColor(Color.BLACK);root.addView(title);
        status=label("กำลังตรวจสอบ...");root.addView(status);

        Button access=button("1) เปิด Accessibility");
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(access);

        Button overlay=button("2) อนุญาต Overlay");
        overlay.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
            else Toast.makeText(this,"Overlay พร้อมแล้ว",Toast.LENGTH_SHORT).show();
        });root.addView(overlay);

        Button capture=button("3) เริ่มจับภาพหน้าจอ");
        capture.setOnClickListener(v->requestCapture());root.addView(capture);

        root.addView(label("ตำแหน่งปุ่มโจมตี"));
        attackX=field("Attack X",String.valueOf(Config.get(this,"attackX",1290)));
        attackY=field("Attack Y",String.valueOf(Config.get(this,"attackY",760)));addPair(root,attackX,attackY);

        root.addView(label("จุดเดิน (x,y;x,y;...)"));
        waypoints=new EditText(this);waypoints.setText(Config.get(this,"waypoints",""));
        waypoints.setHint("เช่น 500,700;800,700;800,900;500,900");waypoints.setTextSize(17);root.addView(waypoints);

        root.addView(label("เวลารอ: เดิน / ตี / สแกน (ms)"));
        walkDelay=field("เดิน",String.valueOf(Config.get(this,"walkDelay",1200)));
        attackDelay=field("ตี",String.valueOf(Config.get(this,"attackInterval",700)));
        scanDelay=field("สแกน",String.valueOf(Config.get(this,"scanDelay",800)));
        addPair(root,walkDelay,attackDelay);root.addView(scanDelay);

        root.addView(label("Monster Template: X,Y,W,H"));
        mx=field("X",String.valueOf(Config.get(this,"mx",500)));my=field("Y",String.valueOf(Config.get(this,"my",300)));
        mw=field("W",String.valueOf(Config.get(this,"mw",80)));mh=field("H",String.valueOf(Config.get(this,"mh",80)));
        addPair(root,mx,my);addPair(root,mw,mh);
        Button saveM=button("จับภาพ Monster Template");saveM.setOnClickListener(v->saveTemplate("monster",mx,my,mw,mh));root.addView(saveM);

        root.addView(label("Item Template: X,Y,W,H"));
        ix=field("X",String.valueOf(Config.get(this,"ix",500)));iy=field("Y",String.valueOf(Config.get(this,"iy",300)));
        iw=field("W",String.valueOf(Config.get(this,"iw",50)));ih=field("H",String.valueOf(Config.get(this,"ih",50)));
        addPair(root,ix,iy);addPair(root,iw,ih);
        Button saveI=button("จับภาพ Item Template");saveI.setOnClickListener(v->saveTemplate("item",ix,iy,iw,ih));root.addView(saveI);

        Button save=button("บันทึกค่าทั้งหมด");save.setOnClickListener(v->{saveConfig();Toast.makeText(this,"บันทึกแล้ว",Toast.LENGTH_SHORT).show();});root.addView(save);

        Button open=button("4) เปิดปุ่มลอย BOT");
        open.setOnClickListener(v->{saveConfig();if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"ต้องอนุญาต Overlay ก่อน",Toast.LENGTH_SHORT).show();return;}startService(new Intent(this,BotOverlayService.class));});
        root.addView(open);

        root.addView(label("ลำดับ: ตรวจ Monster → แตะ Monster → โจมตี → ตรวจ Item → เก็บ → เดินตามจุด → วนซ้ำ"));
        sv.addView(root);setContentView(sv);
    }

    private void requestCapture(){
        android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==REQ_CAPTURE && res==RESULT_OK && data!=null){
            CaptureService.start(this,data);
            Toast.makeText(this,"เริ่มจับภาพหน้าจอแล้ว รอประมาณ 2 วินาที",Toast.LENGTH_LONG).show();
        }
    }
    private int val(EditText e,int d){try{return Integer.parseInt(e.getText().toString().trim());}catch(Exception x){return d;}}
    private void saveConfig(){
        Config.put(this,"attackX",val(attackX,1290));Config.put(this,"attackY",val(attackY,760));
        Config.put(this,"walkDelay",val(walkDelay,1200));Config.put(this,"attackInterval",val(attackDelay,700));Config.put(this,"scanDelay",val(scanDelay,800));
        Config.put(this,"mx",val(mx,500));Config.put(this,"my",val(my,300));Config.put(this,"mw",val(mw,80));Config.put(this,"mh",val(mh,80));
        Config.put(this,"ix",val(ix,500));Config.put(this,"iy",val(iy,300));Config.put(this,"iw",val(iw,50));Config.put(this,"ih",val(ih,50));
        Config.put(this,"waypoints",waypoints.getText().toString().trim());
    }
    private void saveTemplate(String name,EditText xe,EditText ye,EditText we,EditText he){
        saveConfig();Bitmap b=CaptureService.latest.get();
        if(b==null){Toast.makeText(this,"ยังไม่มีภาพหน้าจอ กดเริ่มจับภาพก่อน",Toast.LENGTH_SHORT).show();return;}
        int x=val(xe,0),y=val(ye,0),w=val(we,50),h=val(he,50);
        if(x<0||y<0||w<4||h<4||x+w>b.getWidth()||y+h>b.getHeight()){
            Toast.makeText(this,"พื้นที่ Template เกินขอบหน้าจอ",Toast.LENGTH_SHORT).show();return;
        }
        Bitmap crop=Bitmap.createBitmap(b,x,y,w,h);
        try(FileOutputStream out=openFileOutput(name+".png",MODE_PRIVATE)){
            crop.compress(Bitmap.CompressFormat.PNG,100,out);
            Toast.makeText(this,"บันทึก "+name+" template แล้ว",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"บันทึกไม่สำเร็จ",Toast.LENGTH_SHORT).show();}
        finally{crop.recycle();}
    }
    private void refresh(){
        boolean a=BotAccessibilityService.instance!=null,o=Settings.canDrawOverlays(this),c=CaptureService.latest.get()!=null;
        status.setText("สถานะ: Accessibility "+(a?"พร้อม":"ยังไม่เปิด")+" | Overlay "+(o?"พร้อม":"ยังไม่อนุญาต")+" | Capture "+(c?"พร้อม":"ยังไม่เริ่ม"));
        status.setTextColor(a&&o&&c?Color.rgb(0,140,0):Color.rgb(190,90,0));
    }
}
