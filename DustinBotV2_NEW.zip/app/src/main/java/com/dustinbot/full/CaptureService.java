package com.dustinbot.full;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.*;
import android.hardware.display.DisplayManager;
import android.os.*;
import java.util.concurrent.atomic.AtomicReference;

public class CaptureService extends Service {
    public static final int REQ=501;
    public static final AtomicReference<Bitmap> latest=new AtomicReference<>(null);
    private static MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private int w,h,density;
    private final ImageReader.OnImageAvailableListener listener = r -> {
        Image im=null;
        try{
            im=r.acquireLatestImage();
            if(im==null) return;
            Image.Plane[] ps=im.getPlanes();
            if(ps.length==0) return;
            int pw=ps[0].getPixelStride(), row=ps[0].getRowStride();
            int pad=row-pw*w;
            Bitmap raw=Bitmap.createBitmap(w+pad/pw,h,Bitmap.Config.ARGB_8888);
            raw.copyPixelsFromBuffer(ps[0].getBuffer());
            Bitmap clean=Bitmap.createBitmap(raw,0,0,w,h);
            raw.recycle();
            Bitmap old=latest.getAndSet(clean);
            if(old!=null && !old.isRecycled()) old.recycle();
        }catch(Throwable ignored){} finally { if(im!=null) im.close(); }
    };

    public static void start(Context c, Intent data){
        Intent i=new Intent(c,CaptureService.class);
        i.putExtra("result",data);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i);
    }
    @Override public int onStartCommand(Intent in,int flags,int id){
        startForeground(20,notification());
        try{
            Intent data=in.getParcelableExtra("result");
            MediaProjectionManagerHack(data);
        }catch(Throwable ignored){}
        return START_STICKY;
    }
    private void MediaProjectionManagerHack(Intent data){
        if(data==null)return;
        android.media.projection.MediaProjectionManager m=
                (android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(Activity.RESULT_OK,data);
        density=getResources().getDisplayMetrics().densityDpi;
        w=getResources().getDisplayMetrics().widthPixels;
        h=getResources().getDisplayMetrics().heightPixels;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(listener,new Handler(Looper.getMainLooper()));
        display=projection.createVirtualDisplay("DustinBotCapture",w,h,density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
    }
    private Notification notification(){
        String ch="capture";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(
                new NotificationChannel(ch,"Dustin Bot Capture",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this,ch)
                .setContentTitle("Dustin Bot V2")
                .setContentText("กำลังจับภาพหน้าจอสำหรับระบบบอท")
                .setSmallIcon(android.R.drawable.ic_menu_view).build();
    }
    @Override public void onDestroy(){
        if(display!=null)display.release();
        if(reader!=null)reader.close();
        Bitmap b=latest.getAndSet(null); if(b!=null&&!b.isRecycled())b.recycle();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
