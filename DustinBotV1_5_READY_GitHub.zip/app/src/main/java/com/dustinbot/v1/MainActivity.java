package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setFontFeatureSettings("kern");
        return v;
    }

    private TextView control(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(18);
        v.setTextColor(Color.BLACK);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        v.setClickable(true);
        v.setFocusable(true);
        v.setPadding(dp(8), 0, dp(8), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(225, 225, 225));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.rgb(180, 180, 180));
        v.setBackground(bg);

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(58));
        p.setMargins(0, dp(7), 0, dp(7));
        v.setLayoutParams(p);
        return v;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.WHITE);

        TextView title = label("Dustin Bot V1.5", 30, Color.BLACK);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(55)));

        TextView info = label(
                "ฐานระบบบอท\n\n" +
                "1. Accessibility\n" +
                "2. ปุ่มลอย BOT / STOP\n" +
                "3. ทดสอบแตะหน้าจอ\n\n" +
                "ขั้นต่อไป: เดิน → หา Monster → ตี → เก็บของ",
                19, Color.DKGRAY);
        root.addView(info, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        status = label("", 19, Color.rgb(0, 140, 0));
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        TextView access = control("เปิด ACCESSIBILITY");
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        TextView overlay = control("เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
            startService(new Intent(this, BotOverlayService.class));
            updateStatus();
        });
        root.addView(overlay);

        TextView stop = control("ปิดปุ่มลอย");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, BotOverlayService.class));
            updateStatus();
        });
        root.addView(stop);

        setContentView(root);
    }

    private void updateStatus() {
        if (status == null) return;

        boolean a11y = BotAccessibilityService.isRunning();
        boolean overlay = Settings.canDrawOverlays(this);

        status.setText("สถานะ: Accessibility " +
                (a11y ? "พร้อม" : "ยังไม่เปิด") +
                " | Overlay " +
                (overlay ? "พร้อม" : "ยังไม่อนุญาต"));

        status.setTextColor(a11y
                ? Color.rgb(0, 140, 0)
                : Color.rgb(190, 90, 0));
    }
}
