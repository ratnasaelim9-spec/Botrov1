package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

public class BotOverlayService extends Service {
    private WindowManager wm;
    private LinearLayout overlay;

    private static final float TEST_X = 600f;
    private static final float TEST_Y = 700f;

    @Override
    public void onCreate() {
        super.onCreate();

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(10), dp(10), dp(10), dp(10));
        overlay.setBackgroundColor(Color.rgb(45, 45, 45));

        TextView bot = makeButton("BOT");
        TextView stop = makeButton("STOP");
        TextView test = makeButton("แตะทดสอบ");

        bot.setOnClickListener(v ->
                Toast.makeText(this,
                        "BOT: ระบบเดิน/หา Monster/ตี/เก็บของยังไม่เปิด",
                        Toast.LENGTH_SHORT).show());

        stop.setOnClickListener(v ->
                Toast.makeText(this, "STOP",
                        Toast.LENGTH_SHORT).show());

        test.setOnClickListener(v -> {
            if (!BotAccessibilityService.isRunning()) {
                Toast.makeText(this,
                        "Accessibility ยังไม่เชื่อมต่อ",
                        Toast.LENGTH_LONG).show();
                return;
            }

            boolean sent = BotAccessibilityService.tap(TEST_X, TEST_Y);
            Toast.makeText(this,
                    sent ? "ส่งแตะ: 600,700" : "ส่งคำสั่งแตะไม่สำเร็จ",
                    Toast.LENGTH_SHORT).show();
        });

        overlay.addView(bot);
        overlay.addView(stop);
        overlay.addView(test);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(190),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = dp(10);
        lp.y = dp(180);

        wm.addView(overlay, lp);
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeButton(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(17);
        v.setTextColor(Color.BLACK);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        v.setClickable(true);
        v.setFocusable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(225, 225, 225));
        bg.setCornerRadius(dp(7));
        bg.setStroke(dp(1), Color.rgb(170, 170, 170));
        v.setBackground(bg);

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(dp(166), dp(60));
        p.setMargins(0, dp(5), 0, dp(5));
        v.setLayoutParams(p);
        return v;
    }

    @Override
    public void onDestroy() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        }
        overlay = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
