# Dustin Bot V1.4

แก้ระบบแตะหน้าจอด้วย AccessibilityService.dispatchGesture โดยตรง
และตัด dependency Kotlin/AppCompat ออก เพื่อลดปัญหา duplicate Kotlin stdlib

V1.4 ยังเป็นฐานทดสอบ gesture เท่านั้น
ระบบเดิน / หา Monster / ตี / เก็บของ จะเพิ่มในขั้นถัดไป
