package com.dustinbot.v1;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class BotOverlayService extends Service {
    private WindowManager wm; private LinearLayout box;
    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundColor(Color.WHITE);
        Button bot=new Button(this); bot.setText("BOT"); bot.setOnClickListener(v->Toast.makeText(this,"BOT เริ่มทำงาน (โหมดทดสอบ)",Toast.LENGTH_SHORT).show());
        Button stop=new Button(this); stop.setText("STOP"); stop.setOnClickListener(v->Toast.makeText(this,"BOT หยุดแล้ว",Toast.LENGTH_SHORT).show());
        Button tap=new Button(this); tap.setText("แตะทดสอบ"); tap.setOnClickListener(v->BotAccessibilityService.tap(600,700));
        box.addView(bot); box.addView(stop); box.addView(tap);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.x=10; p.y=150; wm.addView(box,p);
    }
    @Override public void onDestroy(){ if(wm!=null&&box!=null) try{wm.removeView(box);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
