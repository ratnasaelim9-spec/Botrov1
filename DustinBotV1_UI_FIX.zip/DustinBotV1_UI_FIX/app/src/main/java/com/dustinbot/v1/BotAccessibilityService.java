package com.dustinbot.v1;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public class BotAccessibilityService extends AccessibilityService {
    private static BotAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    public static boolean isReady() { return instance != null; }
    public static void tap(float x, float y) {
        if (instance == null || Build.VERSION.SDK_INT < 24) return;
        Path p = new Path(); p.moveTo(x,y);
        GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        instance.dispatchGesture(g, null, null);
    }
}
