package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(0, dp(8), 0, dp(8));
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root, new ViewGroup.LayoutParams(-1, -1));

        TextView title = text("Dustin Bot V1", 30);
        title.setGravity(Gravity.CENTER); title.setTextColor(Color.rgb(25,80,150));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView ok = text("แอปเปิดทำงานแล้ว ✓\nUI FIX v1.1", 18);
        ok.setGravity(Gravity.CENTER); ok.setTextColor(Color.rgb(20,120,60));
        root.addView(ok, new LinearLayout.LayoutParams(-1, -2));

        root.addView(text("ทดสอบระบบ", 21));

        Button acc = new Button(this);
        acc.setText("เปิด ACCESSIBILITY");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        Button overlay = new Button(this);
        overlay.setText("เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
                status.setText("ไปอนุญาตการแสดงทับแอปอื่น แล้วกลับมาอีกครั้ง");
            } else {
                startService(new Intent(this, BotOverlayService.class));
                status.setText("เปิดปุ่มลอยแล้ว ✓");
            }
        });
        root.addView(overlay);

        Button test = new Button(this);
        test.setText("แตะทดสอบ (600,700)");
        test.setOnClickListener(v -> {
            if (BotAccessibilityService.isReady()) {
                BotAccessibilityService.tap(600,700);
                status.setText("ส่งคำสั่งแตะแล้ว ✓");
            } else status.setText("กรุณาเปิด Accessibility ก่อน");
        });
        root.addView(test);

        Button stop = new Button(this);
        stop.setText("ปิดปุ่มลอย");
        stop.setOnClickListener(v -> { stopService(new Intent(this, BotOverlayService.class)); status.setText("ปิดปุ่มลอยแล้ว"); });
        root.addView(stop);

        status = text("สถานะ: พร้อมใช้งาน", 17);
        status.setTextColor(Color.rgb(20,80,120));
        root.addView(status);

        root.addView(text("ขั้นต่อไป: เดิน → ตรวจจับ Monster → โจมตี → ตรวจจับของ → เก็บของ → วนลูป", 16));
        setContentView(scroll);
    }
}
