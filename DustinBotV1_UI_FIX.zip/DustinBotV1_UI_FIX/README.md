# DustinBotV1 UI FIX
Clean Android Java build with no AndroidX/AppCompat dependency. The first goal is to verify that MainActivity opens and displays its UI correctly on Android 16. Bot movement, monster detection and loot are not included yet.
