package com.dustinbot.v1;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView status;
    private TextView accessibilityStatus;
    private TextView overlayStatus;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(Color.DKGRAY);
        v.setPadding(0, dp(6), 0, dp(6));
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root);

        TextView title = label("Dustin Bot V1", 30);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.rgb(30, 80, 150));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = label("เครื่องมือช่วยควบคุม Dustin RO\nเวอร์ชันพื้นฐานสำหรับทดสอบ Accessibility", 16);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        root.addView(label("สถานะระบบ", 20));
        accessibilityStatus = label("Accessibility: กำลังตรวจสอบ...", 16);
        root.addView(accessibilityStatus);
        overlayStatus = label("ปุ่มลอย: กำลังตรวจสอบ...", 16);
        root.addView(overlayStatus);

        Button accessibility = new Button(this);
        accessibility.setText("เปิด ACCESSIBILITY");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button overlay = new Button(this);
        overlay.setText("เปิดปุ่มลอย BOT");
        overlay.setOnClickListener(v -> openOverlay());
        root.addView(overlay);

        root.addView(label("การทดสอบ", 20));
        Button test = new Button(this);
        test.setText("แตะทดสอบ (600,700)");
        test.setOnClickListener(v -> {
            if (BotAccessibilityService.isReady()) {
                BotAccessibilityService.tap(600, 700);
                status.setText("ทดสอบแตะแล้ว: (600,700)");
            } else {
                status.setText("ยังไม่พร้อม: เปิด Accessibility ก่อน");
            }
        });
        root.addView(test);

        Button stopOverlay = new Button(this);
        stopOverlay.setText("ปิดปุ่มลอย");
        stopOverlay.setOnClickListener(v -> {
            stopService(new Intent(this, BotOverlayService.class));
            status.setText("ปิดปุ่มลอยแล้ว");
            updateStatus();
        });
        root.addView(stopOverlay);

        root.addView(label("สถานะ", 20));
        status = label("พร้อม", 17);
        status.setTextColor(Color.rgb(20, 120, 60));
        root.addView(status);

        TextView next = label(
                "ขั้นต่อไป:\n" +
                "1. ตั้งค่าจุดเดิน\n" +
                "2. ตรวจจับ Monster\n" +
                "3. เดินเข้าเป้าหมายและโจมตี\n" +
                "4. ตรวจจับไอเทมและเก็บของ\n" +
                "5. วนลูป พร้อมปุ่ม STOP ฉุกเฉิน", 16);
        next.setPadding(0, dp(16), 0, 0);
        root.addView(next);

        setContentView(scroll);
        updateStatus();
    }

    private void openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            status.setText("ไปเปิดสิทธิ์แสดงทับแอปอื่น แล้วกลับมาเปิดปุ่มลอยอีกครั้ง");
        } else {
            startService(new Intent(this, BotOverlayService.class));
            status.setText("เปิดปุ่มลอยแล้ว");
            updateStatus();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        boolean accessibilityReady = BotAccessibilityService.isReady();
        accessibilityStatus.setText("Accessibility: " + (accessibilityReady ? "พร้อมใช้งาน ✓" : "ยังไม่เปิด"));
        boolean overlayReady = Settings.canDrawOverlays(this);
        overlayStatus.setText("สิทธิ์ปุ่มลอย: " + (overlayReady ? "อนุญาตแล้ว ✓" : "ยังไม่ได้อนุญาต"));
    }
}
